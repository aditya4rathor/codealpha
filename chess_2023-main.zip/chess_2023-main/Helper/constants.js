const ROOT_DIV = document.getElementById("root");

export { ROOT_DIV };
